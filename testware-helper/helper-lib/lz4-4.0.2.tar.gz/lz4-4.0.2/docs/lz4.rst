
lz4 package
===========

Most of the functionality of this package is found in the :py:mod:`lz4.frame`,
the :py:mod:`lz4.block` and the :py:mod:`lz4.stream` sub-packages.

Contents
--------

.. automodule:: lz4
    :members:
       library_version_number,
       library_version_string,
       __version__
